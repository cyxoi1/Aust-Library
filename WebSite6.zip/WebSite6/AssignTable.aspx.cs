﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


public partial class AssignTable : System.Web.UI.Page
{
      SqlConnection con = new SqlConnection(@"Data Source=Z59\sqlexpress;Initial Catalog=Library;Integrated Security=True");
    SqlCommand cmd,cmd1;
    SqlCommand pwd,pwd1;
    //SqlCommand name1;
    //SqlDataAdapter da;
   //DataSet ds;
    string qr, pass,qr1,pass1;

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con.Open();
        qr = "Select count(*) from Assign where id = '" + TextBox1.Text + "'";
        cmd = new SqlCommand(qr, con);
        int temp = Convert.ToInt32(cmd.ExecuteScalar().ToString());
        con.Close();
        if (temp == 1)
        {
            con.Open();
            pass = "Delete  from Assign where id = '" + TextBox1.Text + "'";
            pwd = new SqlCommand(pass, con);
            int i = pwd.ExecuteNonQuery();
            if (i > 0)
            {
                Response.Write("Deleted record for id: " + TextBox1.Text);
            }

        }
    }
}