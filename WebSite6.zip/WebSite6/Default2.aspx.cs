﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class Default2 : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=Z59\sqlexpress;Initial Catalog=Library;Integrated Security=True");

    SqlCommand cmd;
    SqlCommand pwd;
    SqlCommand name1,id1,sem,dept,phn;
    SqlDataAdapter da;
    DataSet ds;
    string qr, pass, name;
    
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void TextBox4_TextChanged(object sender, EventArgs e)
    {

    }
    protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {

            qr = "Insert into Student(id, name, password, semester, department, mail, [phn no]) values('" + TextBox2.Text.Trim() + "','" + TextBox1.Text.Trim() + "','" + TextBox3.Text.Trim() + "','" + Label1.Text.Trim() + "','" + Label2.Text.Trim() + "','" + TextBox6.Text.Trim() + "','" + TextBox7.Text.Trim()+"')";
            cmd = new SqlCommand(qr, con);
            con.Open();
            if (TextBox1.Text == "")
            {
                Response.Write("Must fill name");
                con.Close();
            }
            if (TextBox3.Text == "")
            {
                Response.Write("Must fill password");
                con.Close();
            }
            /*if (TextBox4.Text == "")
            {
                Response.Write("Must fill semester");
                con.Close();
            }
            if (TextBox5.Text == "")
            {
                Response.Write("Must fill dept");
                con.Close();
            }*/
            if (TextBox6.Text == "")
            {
                Response.Write("Must fill email");
                con.Close();
            }
            if (TextBox7.Text == "")
            {
                Response.Write("Must fill phn no");
                con.Close();
            }
            int i = cmd.ExecuteNonQuery();
            if (i > 0)
            {
              Label3.Text ="Succesfully registered";
               // Response.Write("Succesfully registered");
                //Response.Redirect("Default4.aspx");
                TextBox1.Text = "";
                TextBox2.Text = "";
                TextBox3.Text = "";
                TextBox6.Text = "";
                TextBox7.Text = "";
                Label1.Text = "";
                Label2.Text = "";
                
            }
            else
            {
                Response.Write("Record not inserted");
            }
            con.Close();

        }
        catch(Exception ex)
        {
            con.Close();
            Response.Write("Error:"+ex.ToString());
        }
       

        
    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
    protected void TextBox3_TextChanged(object sender, EventArgs e)
    {
        
    }

    bool log = false;
    protected void Button2_Click(object sender, EventArgs e)
    {
        //Response.Redirect("Default5.aspx");
        con.Open();
        qr = "Select count(*) from Student where id = '" + TextBox8.Text + "'";
        cmd = new SqlCommand(qr, con);
        int temp = Convert.ToInt32(cmd.ExecuteScalar().ToString());
        con.Close();
        if (temp == 1)
        {
            con.Open();
            pass = "Select password from Student where id = '" + TextBox8.Text + "'";
            pwd = new SqlCommand(pass, con);
            string password = pwd.ExecuteScalar().ToString().Replace(" ", "");
            if (password == TextBox9.Text)
            {
               
                name = "Select name from Student where id = '" + TextBox8.Text + "'";
                name1 = new SqlCommand(name, con);
                string showname = name1.ExecuteScalar().ToString();
                Session["param"] = showname;
                string id = "Select id from Student where id = '" + TextBox8.Text + "'";
                id1 = new SqlCommand(id, con);
                string showid = id1.ExecuteScalar().ToString();
                Session["p1"] = showid;
                string semester = "Select semester from Student where id = '" + TextBox8.Text + "'";
                sem = new SqlCommand(semester, con);
                string showsem = sem.ExecuteScalar().ToString();
                Session["p2"] = showsem;
                string department = "Select department from Student where id = '" + TextBox8.Text + "'";
                dept = new SqlCommand(department, con);
                string showdept = dept.ExecuteScalar().ToString();
                Session["p3"] = showdept;
                string phoneno = "Select [phn no] from Student where id = '" + TextBox8.Text + "'";
                phn = new SqlCommand(phoneno, con);
                string showphn = phn.ExecuteScalar().ToString();
                Session["p4"] = showphn;
                //Response.Write("\nWelcome " + showname);
                Response.Redirect("stuenthome.aspx");
                log = true;
                
            }
            else
                Response.Write("Wrong password");
        }
        else
        {
            Response.Write("ID not correct");
        }

    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        //Label1.Text = DropDownList1.SelectedItem.Text;
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Label1.Text = DropDownList1.SelectedItem.Text;
        Label2.Text = DropDownList2.SelectedItem.Text;
    }
}