﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


public partial class StudentEdit : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=Z59\sqlexpress;Initial Catalog=Library;Integrated Security=True");
    SqlCommand cmd,cmd1;
    SqlCommand pwd,pwd1;
    //SqlCommand name1;
    //SqlDataAdapter da;
   //DataSet ds;
    string qr, pass,qr1,pass1;

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click1(object sender, EventArgs e)
    {
        con.Open();
        qr = "Select count(*) from Student where id = '" + TextBox1.Text + "'";
        qr1 = "Select count(*) from Request2 where s_id = '" + TextBox1.Text + "'";
        cmd = new SqlCommand(qr, con);
        cmd1 = new SqlCommand(qr1, con);
        int temp = Convert.ToInt32(cmd.ExecuteScalar().ToString());
        int temp1 = Convert.ToInt32(cmd1.ExecuteScalar().ToString());
        con.Close();
        if (temp == 1)
        {
            con.Open();
            pass = "Delete  from Student where id = '" + TextBox1.Text + "'";
            pwd = new SqlCommand(pass, con);
            int i = pwd.ExecuteNonQuery();
            if (i > 0)
            {
                Response.Write("Deleted record for id: " + TextBox1.Text);
            }

        }
        if (temp1 > 0)
        {
            con.Open();
            pass1 = "Delete  from Request2 where s_id = '" + TextBox1.Text + "'";
            pwd1 = new SqlCommand(pass1, con);
            int i = pwd1.ExecuteNonQuery();
            if (i > 0)
            {
                Response.Write("Deleted record for id: " + TextBox1.Text);
            }

        }
    }
}