﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


public partial class request : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=Z59\sqlexpress;Initial Catalog=Library;Integrated Security=True");
    SqlCommand cmd, cmd1, cmd2;
    SqlCommand ins,check;
    string idcheck;
    int temp;
    protected void Page_Load(object sender, EventArgs e)
    {

        string id = (string)Session["p1"];
        TextBox1.Text = id;
        TextBox1.ReadOnly = true;
        string name = (string)Session["param"];
        TextBox2.Text = name;
        TextBox2.ReadOnly = true;
        string sem = (string)Session["p2"];
        TextBox3.Text = sem;
        TextBox3.ReadOnly = true;
        string dept = (string)Session["p3"];
        TextBox4.Text = dept;
        TextBox4.ReadOnly = true;
        string phn = (string)Session["p4"];
        TextBox5.Text = phn;
        TextBox5.ReadOnly = true;
        //TextBox6.ReadOnly = true;
        TextBox7.ReadOnly = true;
        TextBox8.ReadOnly = true;
        TextBox9.ReadOnly = true;
    }

    protected void TextBox7_TextChanged(object sender, EventArgs e)
    {


    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            string qr, qr1, qr2;
            qr = "Select bookname from BookRecord2 where bookid = '" + TextBox6.Text + "' ";
            cmd = new SqlCommand(qr, con);
            con.Open();
            cmd.ExecuteNonQuery();
            string bookname = cmd.ExecuteScalar().ToString();
            TextBox7.Text = bookname;
            TextBox7.ReadOnly = true;
            TextBox6.ReadOnly = true;
            qr1 = "Select bookquantity from BookRecord2 where bookid = '" + TextBox6.Text + "' ";
            cmd1 = new SqlCommand(qr1, con);
            cmd1.ExecuteNonQuery();
            string bookqty = cmd1.ExecuteScalar().ToString();
            TextBox8.Text = bookqty;
            TextBox8.ReadOnly = true;
            TextBox6.ReadOnly = true;
            qr2 = "Select bookprice from BookRecord2 where bookid = '" + TextBox6.Text + "' ";
            cmd2 = new SqlCommand(qr2, con);
            cmd2.ExecuteNonQuery();
            string bookprice = cmd2.ExecuteScalar().ToString();
            TextBox9.Text = bookprice;
            TextBox9.ReadOnly = true;
            TextBox6.ReadOnly = true;
           
           
           
        }
        catch (Exception ex)
        {
            con.Close();
        }
        con.Close();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        try
        {
            string qs = "Insert into Request2(s_id,s_name,semester,department,phnno,b_id,b_name,recorddate) values('" + TextBox1.Text.Trim() + "','" + TextBox2.Text.Trim() + "','" + TextBox3.Text.Trim() + "','" + TextBox4.Text.Trim() + "','" + TextBox5.Text.Trim() + "','" + TextBox6.Text.Trim() + "','" + TextBox7.Text.Trim() + "', + '" + DateTime.Today.Date.ToShortDateString() + "')";
            ins = new SqlCommand(qs, con);
            con.Open();

            if (TextBox1.Text == "" || TextBox2.Text == "" || TextBox3.Text == "" || TextBox4.Text == "" || TextBox5.Text == "" || TextBox6.Text == "" || TextBox7.Text == "")
            {
                Label2.Text = "Fill out all the fields";
                con.Close();
            }
            //con.Open();
           
            
            //con.Close();

           // int count = Convert.ToInt32(idcheck);
            int x = countrequestStudent();

            if (x > 10)
            {
                Label3.Text = "Request limit exceeded";
                con.Close();
            }
            int i = ins.ExecuteNonQuery();
            if (i > 0)
            {
                Label1.Text = "Request taken";
                //Label1.ForeColor = Green;
                Label2.Visible = false;
                Label3.Visible = false;
            }
            
        }
        catch (Exception ex)
        {
            con.Close();
            Label1.Text = "Exception : " + ex.ToString();
            //Label4.Text = "Request:" + --temp;
            
        }
        con.Close();
    }

    public System.Drawing.Color Green { get; set; }
    public int countrequestStudent()
    {
        idcheck = "Select count(*) from Request2 where s_id = '" + TextBox1.Text + "'";
        check = new SqlCommand(idcheck, con);

        check.ExecuteNonQuery();
        temp = Convert.ToInt32(check.ExecuteScalar().ToString());
        //Label4.Text = "Request:" + ++temp;
        return ++temp;
    }
}
