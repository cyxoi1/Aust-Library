﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;



public partial class Default5 : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=Z59\sqlexpress;Initial Catalog=Library;Integrated Security=True");

    SqlCommand cmd;
    SqlCommand pwd;
    SqlCommand name1;
    SqlDataAdapter da;
    DataSet ds;
    string qr,pass,name;
    


    protected void Page_Load(object sender, EventArgs e)
    {

    }

    bool admin = false;
    protected void Button1_Click1(object sender, EventArgs e)
    {
        con.Open();
        qr = "Select count(*) from AdminPanel2 where name = '" + TextBox2.Text + "'";
        cmd = new SqlCommand(qr, con);
        int temp = Convert.ToInt32(cmd.ExecuteScalar().ToString());
        con.Close();
        if (temp == 1)
        {
            con.Open();
            pass = "Select pass from AdminPanel2 where name = '" + TextBox2.Text + "'";
            pwd = new SqlCommand(pass, con);
            string password = pwd.ExecuteScalar().ToString().Replace(" ","");
            if (password == TextBox1.Text)
            {
                //Response.Write("Password matched\n");
                name = "Select name from AdminPanel2 where name = '" + TextBox2.Text + "'";
                name1 = new SqlCommand(name, con);
                string showname = name1.ExecuteScalar().ToString();
                //Response.Write("\nWelcome "+ showname);
                Session["param"] = showname;
                //Session["param2"] = 2;
                //Response.Redirect("AdminPage.aspx");
                admin = true;
            }
            else
                Response.Write("Wrong password");
        }
        else
        {
            Response.Write("Name not correct");
        }
        if (admin == true) {
            Response.Redirect("AdminPage.aspx");
        }
        }
    }
