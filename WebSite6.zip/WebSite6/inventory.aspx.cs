﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


public partial class inventory : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=Z59\sqlexpress;Initial Catalog=Library;Integrated Security=True");
    SqlCommand cmd,cmd1;
    SqlDataAdapter da;
    DataSet ds;
    string qr,qr1;

    protected void Page_Load(object sender, EventArgs e)
    {
        string str = (string)Session["param"];
        //Response.Write("Admin logged in as " + str);
    }

    protected void btn_Add_Click(object sender, EventArgs e)
    {
        try
        {

            qr = "Insert into BookRecord2(bookid, bookname, bookpubname, bookpubyear, bookprice, bookquantity, recorddate,category) values('" + txt_bookid.Text.Trim() + "','" + txt_bookname.Text.Trim() + "','" + txt_bookpubname.Text.Trim() + "','" + txt_bookpubyear.Text.Trim() + "','" + txt_bookprice.Text.Trim() + "','" + txt_bookqty.Text.Trim() + "','" + DateTime.Today.Date.ToShortDateString() + "','" + TextBox1.Text.Trim() + "')";
            cmd = new SqlCommand(qr, con);
            con.Open();   //sqlconnection open before save or delete update or serach
            int i = cmd.ExecuteNonQuery();
            if (i > 0)
            {
                lblresult.ForeColor = System.Drawing.Color.Green;
                lblresult.Text = "record Inserted Successfully.....";
                clear();

            }
            else
            {
                lblresult.Text = "record NOT Inserted .....";
                lblresult.ForeColor = System.Drawing.Color.Red;
            }
            con.Close();

        }
        catch(Exception ex)
        {
            con.Close();
            Response.Write("Error"+ex.ToString());
        }
    }
    protected void btn_Add_Reset_Click(object sender, EventArgs e)
    {
        clear();
    }

    private void clear()
    {
        txt_bookid.Text = "";
        txt_bookname.Text = "";
        txt_bookpubname.Text = "";
        txt_bookpubyear.Text = "";
        txt_bookprice.Text = "";
        txt_bookqty.Text = "";
        TextBox1.Text = "";
    }

    private void ResetEditTextbox()
    {
        txt_edit_bookid.Text = "";
        txt_edit_bookid.Style.Add("width", "235px");
        txt_edit_bookid.Style.Add("background", "#ffffff");
        txt_edit_bookid.ReadOnly = false;

        btn_check.Visible = true;
        txt_edit_bookname.Text = "";
        txt_edit_bookpubname.Text = "";
        txt_edit_bookpubdate.Text = "";
        txt_edit_bookprice.Text = "";
        txt_edit_bookqty.Text = "";
        TextBox2.Text = "";
    }
    private void ResetDeleteTextbox()
    {
        txt_delete_bookid.Text = "";
    }

    private void DisableReadOnly_EditTextBoxColor()
    {
        txt_edit_bookname.ReadOnly = true;
        txt_edit_bookname.Style.Add("background", "#dddddd");
        txt_edit_bookpubname.ReadOnly = true;
        txt_edit_bookpubname.Style.Add("background", "#dddddd");
        txt_edit_bookpubdate.ReadOnly = true;
        txt_edit_bookpubdate.Style.Add("background", "#dddddd");
        txt_edit_bookprice.ReadOnly = true;
        txt_edit_bookprice.Style.Add("background", "#dddddd");
        txt_edit_bookqty.ReadOnly = true;
        txt_edit_bookqty.Style.Add("background", "#dddddd");
        TextBox2.ReadOnly = true;
        TextBox2.Style.Add("background", "#dddddd");
    }
    protected void btn_check_Click(object sender, EventArgs e)
    {
        try
        {
            qr = "Select * from BookRecord2 Where bookid='" + txt_edit_bookid.Text.Trim() + "'";
            da = new SqlDataAdapter(qr, con);
            ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                txt_edit_bookid.Text = ds.Tables[0].Rows[0]["bookid"].ToString();
                txt_edit_bookid.Text = ds.Tables[0].Rows[0]["bookid"].ToString();
                txt_edit_bookname.Text = ds.Tables[0].Rows[0]["bookname"].ToString();
                txt_edit_bookpubname.Text = ds.Tables[0].Rows[0]["bookpubname"].ToString();
                txt_edit_bookpubdate.Text = ds.Tables[0].Rows[0]["bookpubyear"].ToString();
                txt_edit_bookprice.Text = ds.Tables[0].Rows[0]["bookprice"].ToString();
                txt_edit_bookqty.Text = ds.Tables[0].Rows[0]["bookquantity"].ToString();
                TextBox2.Text = ds.Tables[0].Rows[0]["category"].ToString();
                btn_check.Visible = false;

                EnableReadOnly_TextBoxColor();


                div_add.Style.Add("display", "none");
                table_Add.Style.Add("display", "none");
                div_edit.Style.Add("display", "block");
                table_Edit.Style.Add("display", "block");
                div_delete.Style.Add("display", "none");
                table_Delete.Style.Add("display", "none");


                txt_edit_bookid.Style.Add("width", "300px");
                txt_edit_bookid.Style.Add("background", "#dddddd");
                txt_edit_bookid.ReadOnly = true;

            }
        }
        catch
        {
            con.Close();
        }
    }
    private void EnableReadOnly_TextBoxColor()
    {
        txt_edit_bookid.ReadOnly = false;
        txt_edit_bookid.Style.Add("background", "#ffffff");
        txt_edit_bookname.ReadOnly = false;
        txt_edit_bookname.Style.Add("background", "#ffffff");
        txt_edit_bookpubname.ReadOnly = false;
        txt_edit_bookpubname.Style.Add("background", "#ffffff");
        txt_edit_bookpubdate.ReadOnly = false;
        txt_edit_bookpubdate.Style.Add("background", "#ffffff");
        txt_edit_bookprice.ReadOnly = false;
        txt_edit_bookprice.Style.Add("background", "#ffffff");
        txt_edit_bookqty.ReadOnly = false;
        txt_edit_bookqty.Style.Add("background", "#ffffff");
        TextBox2.ReadOnly = false;
        TextBox2.Style.Add("background", "#ffffff");
    }
    protected void btn_Add_Cancel_Click(object sender, EventArgs e)
    {
        clear();
    }

    protected void btn_Update_Click(object sender, EventArgs e)
    {
        try
        {
            qr = "Update BookRecord2 set bookname='" + txt_edit_bookname.Text.Trim() + "', bookpubname='" + txt_edit_bookpubname.Text.Trim() + "', bookpubyear='" + txt_edit_bookpubdate.Text.Trim() + "', bookprice='" + txt_edit_bookprice.Text.Trim() + "', bookquantity='" + txt_edit_bookqty.Text.Trim() + "', category='" + TextBox2.Text.Trim() + "' where bookid='" + txt_edit_bookid.Text.Trim() + "'";
            cmd = new SqlCommand(qr, con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            lblresult.Text = "Record Updated Successfully...";
        }
        catch
        {
            con.Close();
        }
    }
    protected void btn_Delete_Click(object sender, EventArgs e)
    {
        try
        {
            qr = "Delete from BookRecord2 where bookid = '" + txt_delete_bookid.Text.Trim() + "'";
            cmd = new SqlCommand(qr, con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

            div_add.Style.Add("display", "none");
            table_Add.Style.Add("display", "none");
            div_edit.Style.Add("display", "none");
            table_Edit.Style.Add("display", "none");
            div_delete.Style.Add("display", "block");
            table_Delete.Style.Add("display", "block");

            lblresult.Text = "Record Deleted Successfully...";
        }
        catch
        {
            con.Close();
        }
        try
        {
            qr1 = "Delete from Request2 where b_id = '" + txt_delete_bookid.Text.Trim() + "'";
            cmd1 = new SqlCommand(qr1, con);
            con.Open();
            cmd1.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            Response.Write("ERROR:" + ex.ToString());
            con.Close();

        }
        con.Close();

    }

    protected void btn_Delete_Reset_Click(object sender, EventArgs e)
    {
        ResetDeleteTextbox();
    }
    protected void btn_Delete_Cancel_Click(object sender, EventArgs e)
    {
        ResetDeleteTextbox();
    }

    protected void btn_Update_Reset_Click(object sender, EventArgs e)
    {
        ResetEditTextbox();
        DisableReadOnly_EditTextBoxColor();
    }
    protected void btn_Update_Cancel_Click(object sender, EventArgs e)
    {
        ResetEditTextbox();
        DisableReadOnly_EditTextBoxColor();
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        TextBox1.Text = DropDownList1.SelectedItem.Text;
        TextBox1.ReadOnly = true;
    }
}